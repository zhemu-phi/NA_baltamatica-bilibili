function output = GS求积(a,b,n,f)
     % [a,b]	
	% n : 积分节点个数
	% f: 支持向量运算的函数
load('gs.mat');
xi = jiedian{n}; % 是列向量
Xi = ((a+b)+(b-a)*xi)./2;
Yi = f(Xi); 
alpha = quanzhong{n}; % 是列向量
A = alpha .* Yi;
Sum = sum(A);
output = (b-a)/2 * Sum;
end