function  GS = 复化GS求积(a,b,n1,n2,f)
     % [a,b]	
	% n1 : 一个小区间内选取的积分节点数目
	% n2 : 将[a,b]分划成 n2 个小区间
	% f: 支持向量运算的函数
S = zeros(1,n2);
h = (b-a)/n2;
k = 0:1:n2;
jd = a + k * h;
for i =1:1:n2
    S(i) = GS求积(jd(i),jd(i+1),n1,f);
end
	GS = sum(S);
end