function T = 复化梯形求积_v1(a,b,n,f)
% [a,b]
% n ：小区间的个数
% f：定义好的函数
    h = (b-a)/n;
    k = 0:1:n;    
    xi = a + k * h;
    yi = f(xi);
    sumy = sum(yi(2:1:n));
    T = (yi(1)/2 + sumy + yi(n+1)/2)*h;
end
		